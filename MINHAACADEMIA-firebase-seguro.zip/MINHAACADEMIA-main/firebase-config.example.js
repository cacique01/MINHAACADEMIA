// Este arquivo NÃO deve conter senhas, service-account JSON ou chaves privadas.
// A configuração abaixo é pública no navegador; ela identifica o seu projeto Firebase.
// Copie para firebase-config.js e preencha com os dados do seu projeto.
window.FIREBASE_CONFIG = {
  apiKey: "COLOQUE_AQUI_O_API_KEY_PUBLICO_DO_FIREBASE",
  authDomain: "SEU-PROJETO.firebaseapp.com",
  projectId: "SEU-PROJETO",
  storageBucket: "SEU-PROJETO.firebasestorage.app",
  messagingSenderId: "SEU_MESSAGING_SENDER_ID",
  appId: "SEU_APP_ID",
  measurementId: "SEU_MEASUREMENT_ID"
};

// URL pública da Cloud Function. Também não é segredo.
// Ex.: https://us-central1-seu-projeto.cloudfunctions.net/recordVisit
window.RECORD_VISIT_URL = "https://us-central1-SEU-PROJETO.cloudfunctions.net/recordVisit";
