# Configuração segura do Firebase

1. Crie um projeto no Firebase.
2. Registre um app Web e copie apenas a configuração Web para `firebase-config.js`.
   Essa configuração é pública e não deve ser tratada como senha.
3. Ative Google Analytics no projeto se quiser os relatórios de uso.
4. Crie o Firestore Database e publique `firestore.rules`.
5. Ative App Check para o app Web usando reCAPTCHA Enterprise e faça a configuração do provedor.
6. Instale o Firebase CLI e faça login localmente.
7. Na pasta do projeto, crie o segredo:
   `firebase functions:secrets:set RATE_LIMIT_SALT`
   Use uma sequência aleatória longa. Nunca coloque esse valor em nenhum arquivo do site.
8. Instale as dependências de `functions/` e publique a função:
   `firebase deploy --only firestore:rules,functions`
9. Atualize `RECORD_VISIT_URL` em `firebase-config.js` com a URL da função publicada.
10. Faça o deploy do conteúdo estático no Netlify.

## Importante

Não envie para o Netlify nem para o GitHub:
- service account JSON;
- chave privada RSA;
- senhas;
- tokens administrativos;
- o valor de `RATE_LIMIT_SALT`.

Se algum segredo real já tiver sido colocado em um arquivo ou commit, considere-o comprometido e faça a rotação/revogação imediatamente.
