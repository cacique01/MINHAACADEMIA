// NÃO coloque senhas, tokens administrativos ou service-account neste arquivo.
// O Firebase Web Config é público por natureza. As regras de segurança ficam no servidor.
window.FIREBASE_CONFIG = {
  apiKey: "COLOQUE_AQUI_O_API_KEY_PUBLICO_DO_FIREBASE",
  authDomain: "SEU-PROJETO.firebaseapp.com",
  projectId: "SEU-PROJETO",
  storageBucket: "SEU-PROJETO.firebasestorage.app",
  messagingSenderId: "SEU_MESSAGING_SENDER_ID",
  appId: "SEU_APP_ID",
  measurementId: "SEU_MEASUREMENT_ID"
};
window.RECORD_VISIT_URL = "https://us-central1-SEU-PROJETO.cloudfunctions.net/recordVisit";
