(async () => {
  const config = window.FIREBASE_CONFIG;
  if (!config || !config.projectId || config.projectId === "SEU-PROJETO") return;

  try {
    const { initializeApp } = await import("https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js");
    const { getAnalytics, isSupported, logEvent } = await import("https://www.gstatic.com/firebasejs/12.3.0/firebase-analytics.js");
    const supported = await isSupported();
    const app = initializeApp(config);
    if (supported) {
      const analytics = getAnalytics(app);
      logEvent(analytics, "page_view");
    }

    // Contador público: somente chama a função uma vez por navegador/dia.
    // A função no servidor ainda aplica App Check + rate limit + regras próprias.
    const visitKey = "meu_treino_visit_" + new Date().toISOString().slice(0, 10);
    if (!localStorage.getItem(visitKey) && window.RECORD_VISIT_URL && !window.RECORD_VISIT_URL.includes("SEU-PROJETO")) {
      const response = await fetch(window.RECORD_VISIT_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source: "web" }),
        credentials: "omit",
        cache: "no-store"
      });
      if (response.ok) localStorage.setItem(visitKey, "1");
      const data = await response.json().catch(() => null);
      if (data && Number.isFinite(data.total)) {
        const el = document.getElementById("access-counter");
        if (el) el.textContent = Number(data.total).toLocaleString("pt-BR");
      }
    }
  } catch (err) {
    // Analytics/contador nunca devem impedir o funcionamento do app.
    console.warn("Firebase desativado ou não configurado.", err);
  }
})();
