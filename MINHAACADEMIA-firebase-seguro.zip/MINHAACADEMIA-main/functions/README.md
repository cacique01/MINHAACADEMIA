# Segurança do contador

- Não coloque `serviceAccountKey.json`, senhas, tokens privados ou credenciais administrativas no site.
- A Cloud Function usa o Admin SDK com as credenciais gerenciadas pelo Firebase; nenhuma credencial privada vai para o navegador.
- Ative Firebase App Check para o app Web e marque a função para exigir App Check.
- Crie o secret `RATE_LIMIT_SALT` no Firebase/Google Secret Manager antes do deploy.
- O navegador só chama a função; ele não tem acesso direto ao documento do contador.
- Firestore Rules bloqueiam leitura e escrita do contador pelo cliente.
- A função aceita apenas POST, restringe a origem do seu Netlify e conta no máximo uma visita por IP por dia.
- `maxInstances` limita a expansão automática da função, mas proteção contra DDoS volumétrico exige também controles de infraestrutura (por exemplo, Cloud Armor) se o tráfego crescer muito.
