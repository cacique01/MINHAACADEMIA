const crypto = require("crypto");
const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();
const RATE_LIMIT_SALT = defineSecret("RATE_LIMIT_SALT");

const ALLOWED_ORIGINS = new Set([
  "https://minhacademia.netlify.app"
]);

function getClientIp(req) {
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string" && forwarded.length) return forwarded.split(",")[0].trim();
  return req.ip || "unknown";
}

function hashKey(value, salt) {
  return crypto.createHash("sha256").update(`${salt}:${value}`).digest("hex");
}

exports.recordVisit = onRequest(
  {
    region: "us-central1",
    cors: false,
    invoker: "public",
    enforceAppCheck: true,
    secrets: [RATE_LIMIT_SALT],
    timeoutSeconds: 10,
    memory: "256MiB",
    maxInstances: 10
  },
  async (req, res) => {
    const origin = req.headers.origin;
    if (origin && !ALLOWED_ORIGINS.has(origin)) {
      return res.status(403).json({ error: "origin_not_allowed" });
    }
    if (req.method !== "POST") return res.status(405).json({ error: "method_not_allowed" });

    const ip = getClientIp(req);
    const day = new Date().toISOString().slice(0, 10);
    const rateKey = hashKey(`${ip}:${day}`, RATE_LIMIT_SALT.value());
    const rateRef = db.collection("visitRateLimits").doc(rateKey);
    const totalRef = db.collection("publicStats").doc("accesses");

    try {
      const result = await db.runTransaction(async (tx) => {
        const rateSnap = await tx.get(rateRef);
        if (rateSnap.exists) {
          const totalSnap = await tx.get(totalRef);
          return { allowed: false, total: totalSnap.exists ? Number(totalSnap.data().total || 0) : 0 };
        }

        const totalSnap = await tx.get(totalRef);
        const current = totalSnap.exists ? Number(totalSnap.data().total || 0) : 0;
        const next = current + 1;
        tx.set(rateRef, { createdAt: FieldValue.serverTimestamp(), day }, { merge: false });
        tx.set(totalRef, { total: next, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
        return { allowed: true, total: next };
      });

      res.set("Cache-Control", "no-store");
      return res.status(200).json({ total: result.total, counted: result.allowed });
    } catch (error) {
      console.error("recordVisit failed", error);
      return res.status(503).json({ error: "temporarily_unavailable" });
    }
  }
);
